﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wh4_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Graphics(object sender, PaintEventArgs e)
        {
            Graphics g=e.Graphics;
            Pen myPen= new Pen(Color. Red,2);
            //رسم المربع علئ الفورم
            g.DrawRectangle(myPen, 10,10,100,100);
            myPen.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap mybitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            int x, y;
            for (x = 0; x < 100; x++)
            {
                y = x;
               // mybitmap.SetPixel(x, y, Color.Red);
                mybitmap.SetPixel(x,10,Color.Blue) ;
               //mybitmap.SetPixel(10,y, Color.Blue);
            }
            pictureBox1.Image = mybitmap;

            this.Invalidate();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        }
    }

